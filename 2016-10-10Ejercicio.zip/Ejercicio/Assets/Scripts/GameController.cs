﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GameController : MonoBehaviour {
	private const int POINT_PER_PART = 5;
	private int score = 0;
	public Text scoreBoard = null;
	private string textScoreBoard = "";
	private GameObject player;
	// Use this for initialization
	void Start () {
		if (scoreBoard != null){
			textScoreBoard = scoreBoard.text;
		}
		player = GameObject.FindGameObjectWithTag ("Player");
	}
		
	// Update is called once per frame
	void Update () {
		
	}

	//Services provided
	public void PartCollected (){
		score += GameController.POINT_PER_PART;
		if (scoreBoard != null){
			scoreBoard.text = textScoreBoard + score;
		}
	}
		
	//Auxilar services

}
